//
//  PopUp.swift
//  Prototype V2
//
//  Created by Dylan Calderon on 4/1/24.
//

import SwiftUI

struct PopupView: View {
    var title: String
    var subtitle: String
    var onTapAction: (() -> Void)?
    
    var body: some View {
        VStack {
            Text(title)
                .font(.headline)
            
            Text(subtitle)
                .foregroundColor(.gray) // Make it darker
                .multilineTextAlignment(.center) // Center the text
                .onTapGesture {
                    onTapAction?()
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .padding(EdgeInsets(top: 0, leading: 20, bottom: 20, trailing: 20))
    }
}
