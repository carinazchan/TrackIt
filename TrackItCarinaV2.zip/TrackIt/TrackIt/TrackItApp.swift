//
//  TrackItApp.swift
//  TrackIt
//
//  Created by Carina Chan on 2/27/24.
//

import SwiftUI

@main
struct TrackItApp: App {
    var body: some Scene {
        WindowGroup {
            //Welcome_TrackIt()
            Account_TrackIt()
            //Settings_TrackIt()
        }
    }
}
