//
//  Settings_TrackIt.swift
//  TrackIt
//
//  Created by Carina Chan on 3/13/24.
//

import SwiftUI

struct Settings_TrackIt: View {
    var body: some View {
        List {
                    Section(header: Text("General")) {
                        NavigationLink(destination: Account_TrackIt()) {
                            Text("Account").navigationBarTitle("Account")
                        }
                        Text("Notifications")
                    }
                    Section(header: Text("Appearance")) {
                        Text("Theme")
                    }
                    Section(header: Text("About")) {
                        Text("Version")
                    }
                }
                .listStyle(GroupedListStyle())
                .navigationBarTitle("Settings")
    }
}

struct ContentView: View {
    var body: some View {
        NavigationView {
            Settings_TrackIt()
                .navigationBarTitle("Settings")
        }
    }
}

#Preview {
    Settings_TrackIt()
}
