//
//  Account_TrackIt.swift
//  TrackIt
//
//  Created by Carina Chan on 3/13/24.
//

import SwiftUI

struct Account_TrackIt: View {
    var body: some View {
        Text("Account Page")
    }
}

#Preview {
    Account_TrackIt()
}

//import UIKit
//
//class Account_TrackIt: UIViewController {
//    
//    @IBOutlet weak var image: UIImageView!
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.image.layer.borderWidth = 1
//        self.image.layer.borderColor = UIColor.white.cgColor
//        self.image.layer.masksToBounds = false
//        self.image.layer.cornerRadius = image.frame.size.height/2
//        self.image.clipsToBounds = true
//        tapgesture()
//        
//    }
//    
//    func tapgesture() {
//        let tap = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
//        image.isUserInteractionEnabled = true
//        image.addGestureRecognizer(tap)
//        
//    }
//    
//    @objc func imageTapped(){
//        let imagePicker = UIImagePickerController()
//        imagePicker.sourceType = .photoLibrary
//        imagePicker.delegate = self
//        self.present(imagePicker, animated: true, completion: nil)
//    }
//}
//
//extension Account_TrackIt: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//    
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo
//info: [UIImagePickerController.InfoKey: Any])
//    {
//        image.image = info[.originalImage] as? UIImage
//        dismiss(animated: true, completion: nil)
//    }
//}
//
//
//#Preview {
//    Account_TrackIt()
//}
