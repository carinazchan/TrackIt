////
////  Interactive_Map.swift
////  Prototype V2
////
////  Created by Dylan Calderon on 4/1/24.
////
//
//import Foundation
//import MapKit
//import SwiftUI
//
// Remaining MapView, PopupView, ContentView_Previews, MapDetailView, SettingsView, FriendsView code
//    struct MapView: UIViewRepresentable {
//        @Binding var region: MKCoordinateRegion
//        @Binding var selectedAnnotation: MyAnnotation?
//
//        func makeUIView(context: Context) -> MKMapView {
//            let mapView = MKMapView()
//            mapView.delegate = context.coordinator
//            
//            // Geocode the addresses and add the annotations
//            let addresses = [
//                "393 N Glassell St, Orange, CA 92866",
//                "2620 E Chapman Ave, Orange, CA 92869"
//            ]
//            
//            for address in addresses {
//                let geocoder = CLGeocoder()
//                geocoder.geocodeAddressString(address) { (placemarks, error) in
//                    if let placemark = placemarks?.first, let location = placemark.location {
//                        let coordinate = location.coordinate
//                        
//                        var title = ""
//                        var subtitle = ""
//                        if address.contains("393 N Glassell St") {
//                            title = "Starbucks"
//                            subtitle = "Starbucks on 393 N Glassell St, Orange, CA 92866.\nTotal Spent this Month: $350"
//                        } else if address.contains("2620 E Chapman Ave") {
//                            title = "Target"
//                            subtitle = "Target on 2620 E Chapman Ave, Orange, CA 92869.\nTotal Spent this Month: $1000"
//                        }
//                        
//                        let annotation = MyAnnotation(
//                            coordinate: coordinate,
//                            title: title,
//                            subtitle: subtitle,
//                            onAnnotationSelected: {
//                                // Handle tap on annotation
//                                withAnimation {
//                                    context.coordinator.parent?.region.center = coordinate
//                                    context.coordinator.parent?.region.span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
//                                }
//                            }
//                        )
//                        mapView.addAnnotation(annotation)
//                    }
//                }
//            }
//            
//            return mapView
//            
//        }
