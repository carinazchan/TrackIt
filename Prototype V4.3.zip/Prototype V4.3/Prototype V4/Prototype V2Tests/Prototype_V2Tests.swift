//
//  Prototype_V2Tests.swift
//  Prototype V2Tests
//
//  Created by Dylan Calderon on 3/14/24.
//

import Interactive_Map
import Dashboard

import XCTest
@testable import Prototype_V2

final class Prototype_V2Tests: XCTestCase {

    override func setUpWithError() throws {
        
        continueAfterFailure = false
    }

    func testInteractiveMapisNotNil() {
        let mapUI = makeUIView()

        XCTAssertNotNil(mapUI, "Map view should not be nil")
    }

    func testDashboardTotalValue() {
        let value = PieChartView.value
        let totalValue = totalValue()

        XCTAssertTrue(totalValue == ($0 + $1.value))

    }

    func testDashboardPathisNotNil() {
        let path = path()

        XCTAssertNotNil(path, "Dashboard path should not be nil")
    }

    func testContentViewContainsFriend() {
        let friend = NavigationView.friend
        let friendList = ContentView.friendList

        XCTAssertTrue(friendList.contains(friend))
    }


    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
