////
////  FriendsList.swift
////  Prototype V2
////
////  Created by Dylan Calderon on 4/1/24.
////
//
import SwiftUI

struct FriendsListView: View {
    var friends: [Friend] = [
        Friend(name: "Dylan", totalSpentThisMonth: 120.50),
        Friend(name: "Zuly", totalSpentThisMonth: 80.20),
        Friend(name: "Carina", totalSpentThisMonth: 110.00),
        Friend(name: "Arian", totalSpentThisMonth: 200.00),
    ]
    
    var body: some View {
        NavigationView {
            List(friends) { friend in
                NavigationLink(destination: FriendDetail(friend: friend)) {
                    VStack(alignment: .leading) {
                        Text(friend.name)
                            .font(.headline)
                        Text(String(format: "Total Spent: $%.2f", friend.totalSpentThisMonth))
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle("Friends List")
        }
    }
}
