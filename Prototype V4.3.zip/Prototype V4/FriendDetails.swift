//
//  FriendDetails.swift
//  Prototype V2
//
//  Created by Dylan Calderon on 4/1/24.
//

import SwiftUI

struct FriendDetail: View {
    let friend: Friend
    
    var body: some View {
        VStack {
            Text("Friend Details")
                .font(.title)
                .padding()
            
            Text("Name: \(friend.name)")
                .font(.headline)
                .padding()
            
            Text(String(format: "Total Spent this Month: $%.2f", friend.totalSpentThisMonth))
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding()
            
            Spacer()
        }
        .navigationTitle(friend.name)
    }
}
