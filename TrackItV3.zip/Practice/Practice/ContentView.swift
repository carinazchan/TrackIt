//
//  Prototype V2.swift
//  TrackIt
//
//  Created by Zuleyka on 3/18/24.
//

import SwiftUI
import MapKit
import Charts


class MyAnnotation: NSObject, Identifiable, MKAnnotation {
    var id = UUID()
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var onAnnotationSelected: (() -> Void)?

    init(coordinate: CLLocationCoordinate2D, title: String?, subtitle: String?, onAnnotationSelected: (() -> Void)? = nil) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        self.onAnnotationSelected = onAnnotationSelected
    }
}

struct ContentView: View {
    @State private var isNavigationActive = false

    var body: some View {
        NavigationView {
            ZStack {
                Color("Color_WelcomePageBackground").ignoresSafeArea()
                
                VStack {
                    Image("WelcomePageLady")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300, height: 300, alignment: .top)
                        .padding(.all)
                        .position(x: 200, y: 450)

                    Image("TrackItLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300, height: 300, alignment: .top)
                        .padding(.all)
                        .position(x: 200, y: -50)

                    NavigationLink(
                        destination: DashboardView(),
                        isActive: $isNavigationActive
                    ) {
                        EmptyView()
                    }
                    .hidden()
                    .frame(width: 0, height: 0)

                    Button(action: {
                        // Action to perform when the button is tapped
                        isNavigationActive = true
                        print("Button tapped!")
                    }) {
                        Text("Get Started")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .font(.headline)
                    }
                    .frame(width: 500, height: 100)
                    .position(x: 200, y: 200)
                }
            }
            .onTapGesture {
                // Action to perform when anywhere on the screen is tapped
                isNavigationActive = true
            }
        }
        
    }
}
    
    struct DashboardView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Image(systemName: "dollarsign.circle.fill")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.green)
                        Text("Dashboard")
                            .font(.title)
                            .fontWeight(.bold)
                    }
                    Text("Welcome back, John Doe!")
                        .font(.headline)
                    
                    Text("Let's take a look at your budget and spending:")
                        .font(.footnote)
                        .fontWeight(.light)
                    
                    Spacer()
                    // Iteration 3 --> Zuly & Carina Pair Programming STARTS
                    // * * * * *  * * * * * * * * * * * * * * * * * * * * * *
                    let budgetType = [
                        (name: "Food", count: 400),
                        (name: "Transportation", count: 150),
                        (name: "Entertainment", count: 250),
                        (name: "Bills", count: 700)
                    ]
                    
                    Chart {
                        ForEach(budgetType, id: \.name) { category in
                            SectorMark(
                                angle: .value("Cup", category.count),
                                innerRadius: .ratio(0.65),
                                angularInset: 2.0
                            )
                            .foregroundStyle(by: .value("Type", category.name))
                            .annotation(position: .overlay) {
                                Text("\(category.count)")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                    .frame(width: 275, height: 275)
                    .chartBackground { proxy in
                        Text("💸")
                            .font(.system(size: 50))
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Budget Overview")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        BudgetItemView(category: "Food", allocatedAmount: "$500", spentAmount: "$400")
                        BudgetItemView(category: "Transportation", allocatedAmount: "$200", spentAmount: "$150")
                        BudgetItemView(category: "Entertainment", allocatedAmount: "$300", spentAmount: "$250")
                    }
                    
                    Divider()
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Recent Transactions")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "Target", amount: "-$50")
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "Whole Foods", amount: "-$30")
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "AMC theatres", amount: "-$25")
                    }
                    
                    Spacer()
                    
                    NavigationBarView() // Assuming this is a custom view for navigation items
                }
                .padding()
            }
            .navigationBarTitle("Dashboard") // Set navigation bar title
        }
        .navigationViewStyle(StackNavigationViewStyle()) // Ensure correct navigation behavior
    }
}

    struct PieChartView: View {
        var dataPoints: [PieChartDataPoint]
        
        var body: some View {
            GeometryReader { geometry in
                ZStack {
                    ForEach(0..<dataPoints.count) { index in
                        PieChartSlice(startAngle: angle(for: index, in: dataPoints, total: totalValue(of: dataPoints)), endAngle: angle(for: index + 1, in: dataPoints, total: totalValue(of: dataPoints)))
                            .fill(dataPoints[index].color)
                            .overlay(
                                Text(String(format: "%.0f", dataPoints[index].value))
                                    .foregroundColor(.white)
                                    .font(.caption)
                                    .padding(4),
                                alignment: .center
                            )
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.width)
            }
        }
        
        public func angle(for index: Int, in dataPoints: [PieChartDataPoint], total: Double) -> Double {
            guard !dataPoints.isEmpty else { return 0 }
            let startAngle = index == 0 ? 0 : dataPoints[..<index].reduce(0) { $0 + ($1.value / total) * 360 }
            return startAngle
        }
        
        public func totalValue(of dataPoints: [PieChartDataPoint]) -> Double {
            return dataPoints.reduce(0) { $0 + $1.value }
        }
    }
    
    struct PieChartSlice: Shape {
        var startAngle: Double
        var endAngle: Double
        
        func path(in rect: CGRect) -> Path {
            var path = Path()
            let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
            path.move(to: center)
            path.addArc(center: center, radius: rect.width / 2, startAngle: Angle(degrees: startAngle), endAngle: Angle(degrees: endAngle), clockwise: false)
            path.closeSubpath()
            return path
        }
    }
    
    struct PieChartDataPoint {
        var value: Double
        var color: Color
    }
    
// Iteration 3 --> Zuly & Carina Pair Programming ENDS
// * * * * *  * * * * * * * * * * * * * * * * * * * * * *
    
    struct NavigationBarItemView: View {
        var systemName: String
        var label: String
        
        var body: some View {
            VStack(spacing: 4) {
                Image(systemName: systemName)
                    .font(.title)
                Text(label)
                    .font(.caption)
            }
            .foregroundColor(.gray)
        }
    }
    
    struct NavigationBarView: View {
        var body: some View {
            HStack {
                NavigationLink(destination: ContentView()) {
                    NavigationBarItemView(systemName: "house.fill", label: "Home")
                }
                Spacer()
                NavigationLink(destination: MapViewContainer()) {
                    NavigationBarItemView(systemName: "map.fill", label: "Map View")
                }
                Spacer()
                NavigationLink(destination: SettingsView()) {
                    NavigationBarItemView(systemName: "gearshape.fill", label: "Settings")
                }
                Spacer()
                NavigationLink(destination: FriendsListView()) {
                    NavigationBarItemView(systemName: "person.3.fill", label: "Friends")
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(UIColor.systemBackground))
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: -2)
        }
    }
    
    
    struct TransactionRowView: View {
        var imageName: String
        var description: String
        var amount: String
        
        var body: some View {
            HStack {
                Image(systemName: imageName)
                    .foregroundColor(.green)
                VStack(alignment: .leading) {
                    Text(description)
                        .font(.headline)
                    Text(amount)
                        .font(.subheadline)
                }
                Spacer()
            }
        }
    }
    
    struct BudgetItemView: View {
        var category: String
        var allocatedAmount: String
        var spentAmount: String
        
        var body: some View {
            HStack {
                VStack(alignment: .leading) {
                    Text(category)
                        .font(.headline)
                    Text("Allocated: \(allocatedAmount)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Text("Spent: \(spentAmount)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                Spacer()
            }
        }
    }
    
    // Remaining MapView, PopupView, ContentView_Previews, MapDetailView, SettingsView, FriendsView code
    struct MapView: UIViewRepresentable {
        @Binding var region: MKCoordinateRegion
        @Binding var selectedAnnotation: MyAnnotation?
        
        func makeUIView(context: Context) -> MKMapView {
            let mapView = MKMapView()
            mapView.delegate = context.coordinator
            
            // Geocode the addresses and add the annotations
            let addresses = [
                "393 N Glassell St, Orange, CA 92866",
                "2620 E Chapman Ave, Orange, CA 92869"
            ]
            
            for address in addresses {
                let geocoder = CLGeocoder()
                geocoder.geocodeAddressString(address) { (placemarks, error) in
                    if let placemark = placemarks?.first, let location = placemark.location {
                        let coordinate = location.coordinate
                        
                        var title = ""
                        var subtitle = ""
                        if address.contains("393 N Glassell St") {
                            title = "Starbucks"
                            subtitle = "Starbucks on 393 N Glassell St, Orange, CA 92866.\nTotal Spent this Month: $350"
                        } else if address.contains("2620 E Chapman Ave") {
                            title = "Target"
                            subtitle = "Target on 2620 E Chapman Ave, Orange, CA 92869.\nTotal Spent this Month: $1000"
                        }
                        
                        let annotation = MyAnnotation(
                            coordinate: coordinate,
                            title: title,
                            subtitle: subtitle,
                            onAnnotationSelected: {
                                // Handle tap on annotation
                                withAnimation {
                                    context.coordinator.parent?.region.center = coordinate
                                    context.coordinator.parent?.region.span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
                                }
                            }
                        )
                        mapView.addAnnotation(annotation)
                    }
                }
            }
            
            return mapView
        }
        
        func updateUIView(_ uiView: MKMapView, context: Context) {
            uiView.setRegion(region, animated: true)
        }
        
        func makeCoordinator() -> Coordinator {
            Coordinator(parent: self)
        }
        
        class Coordinator: NSObject, MKMapViewDelegate {
            var parent: MapView?
            
            init(parent: MapView) {
                self.parent = parent
            }
            
            func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
                if let annotation = view.annotation as? MyAnnotation {
                    parent?.selectedAnnotation = annotation
                    annotation.onAnnotationSelected?()
                }
            }
        }
    }
    
    struct PopupView: View {
        var title: String
        var subtitle: String
        var onTapAction: (() -> Void)?
        
        var body: some View {
            VStack {
                Text(title)
                    .font(.headline)
                
                Text(subtitle)
                    .foregroundColor(.gray) // Make it darker
                    .multilineTextAlignment(.center) // Center the text
                    .onTapGesture {
                        onTapAction?()
                    }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .padding(EdgeInsets(top: 0, leading: 20, bottom: 20, trailing: 20))
        }
    }
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
    
    struct MapDetailView: View { // Add MapDetailView
        var body: some View {
            Text("Map Detail View")
        }
    }
    
    struct SettingsView: View {
        var body: some View {
            Text("Settings")
        }
    }
    
    struct FriendsView: View {
        var body: some View {
            NavigationLink(destination: FriendsListView()) {
                Text("Friends")
            }
        }
    }
    
    struct Friend: Identifiable {
        let id = UUID()
        let name: String
        var totalSpentThisMonth: Double
    }
    
    struct FriendDetail: View {
        let friend: Friend
        
        var body: some View {
            VStack {
                Text("Friend Details")
                    .font(.title)
                    .padding()
                
                Text("Name: \(friend.name)")
                    .font(.headline)
                    .padding()
                
                Text(String(format: "Total Spent this Month: $%.2f", friend.totalSpentThisMonth))
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding()
                
                Spacer()
            }
            .navigationTitle(friend.name)
        }
    }
    
    struct FriendsListView: View {
        var friends: [Friend] = [
            Friend(name: "Dylan", totalSpentThisMonth: 120.50),
            Friend(name: "Zuly", totalSpentThisMonth: 80.20),
            Friend(name: "Carina", totalSpentThisMonth: 110.00),
            Friend(name: "Arian", totalSpentThisMonth: 200.00),
        ]
        
        var body: some View {
            NavigationView {
                List(friends) { friend in
                    NavigationLink(destination: FriendDetail(friend: friend)) {
                        VStack(alignment: .leading) {
                            Text(friend.name)
                                .font(.headline)
                            Text(String(format: "Total Spent: $%.2f", friend.totalSpentThisMonth))
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .navigationTitle("Friends List")
            }
        }
    }
    struct MapViewContainer: View {
        var body: some View {
            MapViewContainerView() // Use MapViewContainerView to encapsulate your MapView
        }
    }
    
    struct MapViewContainerView: View {
        @State public var region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 33.7879, longitude: -117.8531),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        
        @State public var selectedAnnotation: MyAnnotation?
        
        var body: some View {
            NavigationView {
                VStack {
                    MapView(region: $region, selectedAnnotation: $selectedAnnotation)
                    
                    // Display popup when an annotation is selected
                    if let annotation = selectedAnnotation {
                        PopupView(title: annotation.title ?? "", subtitle: annotation.subtitle ?? "") {
                            // Trigger zooming behavior
                            withAnimation {
                                region.center = annotation.coordinate
                                region.span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
                            }
                        }
                    }
                    
                    Button(action: {
                        // Reset to the original view and clear the selectedAnnotation
                        withAnimation {
                            region = MKCoordinateRegion(
                                center: CLLocationCoordinate2D(latitude: 33.7879, longitude: -117.8531),
                                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                            )
                            selectedAnnotation = nil
                        }
                    }, label: {
                        Text("Reset")
                            .frame(width: 250, height: 50, alignment: .center)
                            .background(Color.red)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                    })
                }
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarItems(leading: Text(""), trailing: Text("")) // To align the title in the center
                .navigationTitle("Interactive Map")
            }
        }
        
        
        struct ContentView: View {
            let friends: [Friend] = [
                Friend(name: "Dylan", totalSpentThisMonth: 120.50),
                Friend(name: "Zuly", totalSpentThisMonth: 80.20),
                Friend(name: "Carina", totalSpentThisMonth: 110.00),
                Friend(name: "Arian", totalSpentThisMonth: 200.00),
                // Add more friends as needed
            ]
            
            var body: some View {
                NavigationView {
                    List(friends) { friend in
                        NavigationLink(destination: FriendDetail(friend: friend)) {
                            VStack(alignment: .leading) {
                                Text(friend.name)
                                    .font(.headline)
                                Text(String(format: "Total Spent: $%.2f", friend.totalSpentThisMonth))
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .navigationTitle("Friends List")
                }
            }
        }
        
        struct ContentView_Previews: PreviewProvider {
            static var previews: some View {
                ContentView()
            }
        }
        
        struct FriendDetail_Previews: PreviewProvider {
            static var previews: some View {
                FriendDetail(friend: Friend(name: "John Doe", totalSpentThisMonth: 120.50))
            }
        }
        
        
    }


