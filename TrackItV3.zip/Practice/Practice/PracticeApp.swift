//
//  PracticeApp.swift
//  Practice
//
//  Created by Zuleyka Urieta on 2/26/24.
//

import SwiftUI

@main
struct PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
    
    
    
}
