//
//  Settings.swift
//  Prototype V2
//
//  Created by Carina Chan on 4/2/24.
//


import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Settings to be done")
    }
}
