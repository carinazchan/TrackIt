//
//  Login.swift
//  Prototype V2
//
//  Created by Carina Chan on 4/2/24.
//

import SwiftUI
import XCTest
import ViewInspector

struct ContentView: View {
    @State private var isNavigationActive = false

    var body: some View {
        NavigationView {
            ZStack {
                Color("Color_WelcomePageBackground").ignoresSafeArea()

                NavigationLink(
                    destination: DashboardView(),
                    isActive: $isNavigationActive
                ) {
                    EmptyView()
                }
                .hidden()

                Welcome_TrackIt(isNavigationActive: $isNavigationActive)
            }
        }
    }
}

struct Welcome_TrackIt: View {
    @State private var username = ""
    @State private var password = ""
    @Binding var isNavigationActive: Bool // Receive binding for navigation

    var body: some View {
        VStack {
            Image("TrackItLogo")
                .resizable()
                .scaledToFit()
                .padding()

            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button(action: {
                // Perform login action
                print("Username: \(username), Password: \(password)")
                isNavigationActive = true // Activate the navigation link to navigate to the dashboard
            }) {
                Text("Login")
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
        }
        .padding()
        .navigationBarTitle("Login")
    }
}


class LoginViewTests: XCTestCase {
    
    func testLogin() throws {
        let view = Welcome_TrackIt(isNavigationActive: .constant(false)) // Create an instance of the login view
        
        let usernameField = try view.inspect().textField(0) // Inspect the username text field
        try usernameField.set(text: "testuser") // Set a test username
        
        let passwordField = try view.inspect().secureField(1) // Inspect the password secure field
        try passwordField.set(text: "testpassword") // Set a test password
        
        let loginButton = try view.inspect().button() // Inspect the login button
        try loginButton.tap() // Simulate tapping the login button
        
        XCTAssertTrue(view.isNavigationActive) // Assert that the navigation is activated after tapping the login button
    }
    
}
