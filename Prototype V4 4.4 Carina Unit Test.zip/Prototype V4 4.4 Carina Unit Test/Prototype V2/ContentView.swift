//
//  Prototype V2.swift
//  TrackIt
//
//  Created by Zuleyka on 3/18/24.
//

import SwiftUI
import MapKit
import Charts

class MyAnnotation: NSObject, Identifiable, MKAnnotation {
    var id = UUID()
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var onAnnotationSelected: (() -> Void)?

    init(coordinate: CLLocationCoordinate2D, title: String?, subtitle: String?, onAnnotationSelected: (() -> Void)? = nil) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        self.onAnnotationSelected = onAnnotationSelected
    }
}
    struct NavigationBarItemView: View {
        var systemName: String
        var label: String
        var body: some View {
            VStack(spacing: 4) {
                Image(systemName: systemName)
                    .font(.title)
                Text(label)
                    .font(.caption)
            }
            .foregroundColor(.gray)
        }
    }
    
    struct NavigationBarView: View {
        var body: some View {
            HStack {
                NavigationLink(destination: ContentView()) {
                    NavigationBarItemView(systemName: "house.fill", label: "Home")
                }
                Spacer()
                NavigationLink(destination: MapViewContainer()) {
                    NavigationBarItemView(systemName: "map.fill", label: "Map View")
                }
                Spacer()
                NavigationLink(destination: SettingsView()) {
                    NavigationBarItemView(systemName: "gearshape.fill", label: "Settings")
                }
                Spacer()
                NavigationLink(destination: FriendsListView()) {
                    NavigationBarItemView(systemName: "person.3.fill", label: "Friends")
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(UIColor.systemBackground))
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: -2)
        }
    }
    
    struct TransactionRowView: View {
        var imageName: String
        var description: String
        var amount: String
        
        var body: some View {
            HStack {
                Image(systemName: imageName)
                    .foregroundColor(.green)
                VStack(alignment: .leading) {
                    Text(description)
                        .font(.headline)
                    Text(amount)
                        .font(.subheadline)
                }
                Spacer()
            }
        }
    }
    
    struct BudgetItemView: View {
        var category: String
        var allocatedAmount: String
        var spentAmount: String
        
        var body: some View {
            HStack {
                VStack(alignment: .leading) {
                    Text(category)
                        .font(.headline)
                    Text("Allocated: \(allocatedAmount)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Text("Spent: \(spentAmount)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                Spacer()
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
    
    struct FriendsView: View {
        var body: some View {
            NavigationLink(destination: FriendsListView()) {
                Text("Friends")
            }
        }
    }
    
    struct Friend: Identifiable {
        let id = UUID()
        let name: String
        var totalSpentThisMonth: Double
    }


    struct MapViewContainer: View {
        var body: some View {
            MapViewContainerView() // Use MapViewContainerView to encapsulate your MapView
        }
    }
    
    struct MapViewContainerView: View {
        @State public var region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 33.7879, longitude: -117.8531),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        
        @State public var selectedAnnotation: MyAnnotation?
        
        var body: some View {
            NavigationView {
                VStack {
                    MapView(region: $region, selectedAnnotation: $selectedAnnotation)
                    
                    // Display popup when an annotation is selected
                    if let annotation = selectedAnnotation {
                        PopupView(title: annotation.title ?? "", subtitle: annotation.subtitle ?? "") {
                            // Trigger zooming behavior
                            withAnimation {
                                region.center = annotation.coordinate
                                region.span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
                            }
                        }
                    }
                    
                    Button(action: {
                        // Reset to the original view and clear the selectedAnnotation
                        withAnimation {
                            region = MKCoordinateRegion(
                                center: CLLocationCoordinate2D(latitude: 33.7879, longitude: -117.8531),
                                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                            )
                            selectedAnnotation = nil
                        }
                    }, label: {
                        Text("Reset")
                            .frame(width: 250, height: 50, alignment: .center)
                            .background(Color.red)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                    })
                }
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarItems(leading: Text(""), trailing: Text("")) // To align the title in the center
                .navigationTitle("Interactive Map")
            }
        }
        
        struct ContentView: View {
            let friends: [Friend] = [
                Friend(name: "Dylan", totalSpentThisMonth: 120.50),
                Friend(name: "Zuly", totalSpentThisMonth: 80.20),
                Friend(name: "Carina", totalSpentThisMonth: 110.00),
                Friend(name: "Arian", totalSpentThisMonth: 200.00),
                // Add more friends as needed
            ]
            
            var body: some View {
                NavigationView {
                    List(friends) { friend in
                        NavigationLink(destination: FriendDetail(friend: friend)) {
                            VStack(alignment: .leading) {
                                Text(friend.name)
                                    .font(.headline)
                                Text(String(format: "Total Spent: $%.2f", friend.totalSpentThisMonth))
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .navigationTitle("Friends List")
                }
            }
        }
        
        struct ContentView_Previews: PreviewProvider {
            static var previews: some View {
                ContentView()
            }
        }
        
        struct FriendDetail_Previews: PreviewProvider {
            static var previews: some View {
                FriendDetail(friend: Friend(name: "John Doe", totalSpentThisMonth: 120.50))
            }
        }
    }
