//
//  Dashboard.swift
//  Prototype V2
//
//  Created by Zuleyka Urieta on 4/3/24.
//

import Foundation
import SwiftUI
import Charts


struct DashboardView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Image(systemName: "dollarsign.circle.fill")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.green)
                        Text("Dashboard")
                            .font(.title)
                            .fontWeight(.bold)
                    }
                    Text("Welcome back, John Doe!")
                        .font(.headline)
                    
                    Text("Let's take a look at your budget and spending:")
                        .font(.footnote)
                        .fontWeight(.light)
                    
                    Spacer()
                    
                    let budgetType = [
                        (name: "Food", count: 400),
                        (name: "Transportation", count: 150),
                        (name: "Entertainment", count: 250),
                        (name: "Bills", count: 700)
                    ]
                    
                    Chart {
                        ForEach(budgetType, id: \.name) { category in
                            SectorMark(
                                angle: .value("Cup", category.count),
                                innerRadius: .ratio(0.65),
                                angularInset: 2.0
                            )
                            .foregroundStyle(by: .value("Type", category.name))
                            .annotation(position: .overlay) {
                                Text("\(category.count)")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                    .frame(width: 275, height: 275)
                    .chartBackground { proxy in
                        Text("💸")
                            .font(.system(size: 50))
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Budget Overview")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        BudgetItemView(category: "Food", allocatedAmount: "$500", spentAmount: "$400")
                        BudgetItemView(category: "Transportation", allocatedAmount: "$200", spentAmount: "$150")
                        BudgetItemView(category: "Entertainment", allocatedAmount: "$300", spentAmount: "$250")
                    }
                    
                    Divider()
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Recent Transactions")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "Target", amount: "-$50")
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "Whole Foods", amount: "-$30")
                        TransactionRowView(imageName: "dollarsign.square.fill", description: "AMC theatres", amount: "-$25")
                    }
                    
                    Spacer()
                    
                    NavigationBarView() // Assuming this is a custom view for navigation items
                }
                .padding()
            }
            .navigationBarTitle("Dashboard") // Set navigation bar title
            .navigationBarBackButtonHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle()) // Ensure correct navigation behavior
    }
}

struct PieChartView: View {
    var dataPoints: [PieChartDataPoint]
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                ForEach(0..<dataPoints.count) { index in
                    PieChartSlice(startAngle: angle(for: index, in: dataPoints, total: totalValue(of: dataPoints)), endAngle: angle(for: index + 1, in: dataPoints, total: totalValue(of: dataPoints)))
                        .fill(dataPoints[index].color)
                        .overlay(
                            Text(String(format: "%.0f", dataPoints[index].value))
                                .foregroundColor(.white)
                                .font(.caption)
                                .padding(4),
                            alignment: .center
                        )
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.width)
        }
    }
    
    public func angle(for index: Int, in dataPoints: [PieChartDataPoint], total: Double) -> Double {
        guard !dataPoints.isEmpty else { return 0 }
        let startAngle = index == 0 ? 0 : dataPoints[..<index].reduce(0) { $0 + ($1.value / total) * 360 }
        return startAngle
    }
    
    public func totalValue(of dataPoints: [PieChartDataPoint]) -> Double {
        return dataPoints.reduce(0) { $0 + $1.value }
    }
}

struct PieChartSlice: Shape {
    var startAngle: Double
    var endAngle: Double
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
        path.move(to: center)
        path.addArc(center: center, radius: rect.width / 2, startAngle: Angle(degrees: startAngle), endAngle: Angle(degrees: endAngle), clockwise: false)
        path.closeSubpath()
        return path
    }
}

struct PieChartDataPoint {
    var value: Double
    var color: Color
}
